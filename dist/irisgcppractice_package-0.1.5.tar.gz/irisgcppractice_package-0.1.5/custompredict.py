#CUSTOM PREDICTOR CLASS FOR CUSTOM PREDICTION FOR IRIS GCP PRACTICE

import pickle 
import numpy as np 
import os

class CustomPredictor(object):
	def __init__(self, model):
		self._model = model

	def predict(self, instances, **kwargs):

		inputs = np.asarray(instances)
		outputs = self._model.predict(inputs)

		return outputs.tolist()

		'''results = []
						
								for instance in instances:
									res = cls.model.predict(instance)
									results.append({"instance":str(instance), "result":str(res)})
						
								return results'''

	@classmethod 
	def from_path(cls, model_dir):
		'''
								model = pickle.load(open(model_dir+"/model.pkl", 'rb'))
								return model
						'''

		model_path = os.path.join(model_dir, 'model.pkl')
		with open(model_path, 'rb') as f:
			model = pickle.load(f)

		return cls(model)